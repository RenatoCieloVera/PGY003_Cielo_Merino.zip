from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserChangeForm, PasswordChangeForm
from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import RegisterForm, CustomUserChangeForm
from .models import Product, Cart

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('product_list')
    else:
        form = RegisterForm()
    return render(request, 'tienda/register.html', {'form': form})

def index(request):
    return render(request, 'tienda/index.html')

def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('product_list')
        else:
            return render(request, 'tienda/login.html', {'error': 'Credenciales inválidas'})
    return render(request, 'tienda/login.html')

@login_required
def product_list(request):
    products = Product.objects.all()
    return render(request, 'tienda/product_list.html', {'products': products})

@login_required
def profile(request):
    return render(request, 'tienda/profile.html')

@login_required
def cart(request):
    cart_items = Cart.objects.filter(user=request.user)
    return render(request, 'tienda/cart.html', {'cart_items': cart_items})

@login_required
def logout_view(request):
    logout(request)
    return redirect('index')

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart_item, created = Cart.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
    cart_item.save()
    return redirect('cart')

@login_required
def remove_from_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    if request.method == 'POST':
        cart_item = Cart.objects.get(product=product, user=request.user)
        cart_item.delete()
        messages.success(request, 'Producto eliminado del carrito.')
    return redirect('cart')

@login_required
def clear_cart(request):
    if request.method == 'POST':
        Cart.objects.filter(user=request.user).delete()
        messages.success(request, 'El carrito ha sido vaciado.')
    return redirect('cart')

@login_required
def cart(request):
    cart_items = Cart.objects.filter(user=request.user)
    cart_total = sum(item.quantity * item.product.price for item in cart_items)
    return render(request, 'tienda/cart.html', {'cart_items': cart_items, 'cart_total': cart_total})

@login_required
def increase_quantity(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    cart_item = Cart.objects.get(product=product, user=request.user)
    cart_item.quantity += 1
    cart_item.save()
    messages.success(request, 'Cantidad aumentada correctamente.')
    return redirect('cart')

@login_required
def decrease_quantity(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    cart_item = Cart.objects.get(product=product, user=request.user)
    if cart_item.quantity > 1:
        cart_item.quantity -= 1
        cart_item.save()
        messages.success(request, 'Cantidad reducida correctamente.')
    else:
        cart_item.delete()
        messages.success(request, 'Producto eliminado del carrito.')
    return redirect('cart')

@login_required
def checkout(request):
    return render(request, 'tienda/checkout.html')

@login_required
def profile_edit(request):
    if request.method == 'POST':
        form = CustomUserChangeForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Perfil actualizado con éxito.')
            return redirect('profile')
    else:
        form = CustomUserChangeForm(instance=request.user)
    return render(request, 'tienda/profile_edit.html', {'form': form})

@login_required
def password_change(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  
            messages.success(request, 'Contraseña actualizada con éxito.')
            return redirect('profile')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'tienda/password_change.html', {'form': form})
